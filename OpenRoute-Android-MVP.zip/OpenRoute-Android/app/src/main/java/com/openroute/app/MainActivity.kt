package com.openroute.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.URL
import javax.net.ssl.HttpsURLConnection

private data class TestResult(
    val host: String,
    val dns: String = "Bekliyor",
    val https: String = "Bekliyor",
    val detail: String = "Test başlatılmadı"
)

private val targets = listOf("www.instagram.com", "www.tiktok.com", "github.com")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OpenRouteApp() }
    }
}

@Composable
private fun OpenRouteApp() {
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(targets.map { TestResult(it) }) }
    var summary by remember { mutableStateOf("Ağ bağlantını kontrol etmek için testi başlat.") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF70E1C1),
        secondary = Color(0xFF9DB8FF),
        background = Color(0xFF0B1020),
        surface = Color(0xFF151D30)
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("OpenRoute", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color(0xFF70E1C1))
                Text("Ağ bağlantısı tanılama", style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text("Alan adlarının DNS ve HTTPS erişimini kontrol eder. Bu sürüm VPN kullanmaz, ayarlarını değiştirmez ve engel aşmayı garanti etmez.", color = Color(0xFFB8C2D9), style = MaterialTheme.typography.bodyMedium)

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !running,
                    onClick = {
                        running = true
                        summary = "Testler çalışıyor…"
                        results = targets.map { TestResult(it, "Kontrol ediliyor…", "Kontrol ediliyor…", "") }
                        scope.launch {
                            val updated = targets.map { host ->
                                withContext(Dispatchers.IO) { runTest(host) }
                            }
                            results = updated
                            val passed = updated.count { it.dns == "Başarılı" && it.https == "Başarılı" }
                            summary = "Tamamlandı: ${updated.size} alan adı kontrol edildi; $passed tanesinde hem DNS hem HTTPS başarılı."
                            running = false
                        }
                    }
                ) { Text(if (running) "Test ediliyor…" else "Testleri başlat") }

                if (running) CircularProgressIndicator(color = Color(0xFF70E1C1))
                Text(summary, color = Color.White, style = MaterialTheme.typography.bodyMedium)

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(results, key = { it.host }) { result -> ResultCard(result) }
                }
                Spacer(Modifier.height(2.dp))
                Text("Gizlilik: Uygulama giriş bilgisi toplamaz. Test sırasında yalnızca listelenen sunuculara DNS/HTTPS bağlantısı denenir.", color = Color(0xFF9AA7C2), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ResultCard(result: TestResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151D30))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(result.host, color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("DNS: ${result.dns}", color = statusColor(result.dns))
                Text("HTTPS: ${result.https}", color = statusColor(result.https))
            }
            if (result.detail.isNotBlank()) Text(result.detail, color = Color(0xFFB8C2D9), style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun statusColor(value: String): Color = when (value) {
    "Başarılı" -> Color(0xFF70E1C1)
    "Başarısız" -> Color(0xFFFF8D9B)
    else -> Color(0xFFB8C2D9)
}

private fun runTest(host: String): TestResult {
    val dnsResult = try {
        val addresses = InetAddress.getAllByName(host)
        if (addresses.isNotEmpty()) "Başarılı" else "Başarısız"
    } catch (e: Exception) {
        "Başarısız"
    }

    var httpsResult = "Başarısız"
    var detail = ""
    var connection: HttpsURLConnection? = null
    try {
        connection = (URL("https://$host/").openConnection() as HttpsURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            requestMethod = "HEAD"
            instanceFollowRedirects = true
        }
        val code = connection.responseCode
        httpsResult = if (code in 200..499) "Başarılı" else "Başarısız"
        detail = "HTTPS yanıt kodu: $code"
    } catch (e: Exception) {
        detail = "HTTPS bağlantısı kurulamadı (${e.javaClass.simpleName})."
    } finally {
        connection?.disconnect()
    }
    if (dnsResult == "Başarısız") detail = "DNS çözümlenemedi. " + detail
    return TestResult(host, dnsResult, httpsResult, detail)
}
