# OpenRoute Android — 0.2.0 MVP

A lightweight Android network diagnostics app built with Kotlin and Jetpack Compose.

## Included
- Separate DNS and HTTPS results, with response time in milliseconds.
- Explanations for HTTP 200/404 and common DNS, timeout, TLS and connection failures.
- Last-test timestamp, manual retest, and a small response-time trend chart for the current app session.
- A VPN information screen that clearly states VPN is not configured yet.
- No analytics SDK, account login, or background polling.

## Important VPN note
This build does **not** create a VPN tunnel and does not route traffic through another server. A real VPN needs a compatible, trusted server/endpoint and tunnel protocol (for example WireGuard), secure key/configuration handling, and Android's VPN permission flow. Do not display a connected state until a real tunnel is established. This project intentionally avoids pretending a local VPN interface is a working tunnel.

## Build APK
Open this folder in Android Studio with JDK 17 and Android SDK 35, then run:

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The repository workflow `.github/workflows/android-apk.yml` can build this project in GitHub Actions from `OpenRoute-Android-MVP.zip` and publish the debug APK as an Actions artifact.

## Diagnostics caveats
- HTTP 404 means the server returned an HTTP response but that URL/resource was not found; it is not proof of network blocking.
- DNS/HTTPS tests only describe the tested host and moment. They cannot conclusively identify ISP filtering.
- Test data and trend values are kept in memory for the current app session only.
