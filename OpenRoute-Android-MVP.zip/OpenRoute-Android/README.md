# OpenRoute Android MVP

Android için Kotlin + Jetpack Compose ile hazırlanmış açık kaynaklı ağ tanılama uygulaması.

## Android Studio'da çalıştırma
1. Android Studio'yu aç.
2. **Open** seçip bu `OpenRoute-Android` klasörünü seç.
3. Gradle senkronizasyonunun bitmesini bekle (JDK 17 önerilir).
4. Android cihazda geliştirici seçenekleri/USB hata ayıklamayı aç veya emülatör başlat.
5. **Run** düğmesine bas.

İlk derleme için internet bağlantısı gerekebilir; Gradle bağımlılıkları indirilir.

## Ne yapar?
Kullanıcı düğmeye bastığında `www.instagram.com`, `www.tiktok.com` ve `github.com` için DNS çözümlemesi ve HTTPS HEAD isteği dener. Sonuçlar cihazın mevcut ağ bağlantısını gösterir; tek başına kesin engel teşhisi değildir.

## Güvenlik sınırları
- VPN/proxy kurmaz ve trafiği başka bir yere yönlendirmez.
- DNS veya sistem ayarlarını değiştirmez.
- Hesap, parola veya mesaj istemez.
- Yaş doğrulaması veya hesap düzeyindeki kısıtlamaları atlatmaz.
