package com.openroute.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

private val Ink = Color(0xFF0A1020)
private val Panel = Color(0xFF141D30)
private val Mint = Color(0xFF71E0C0)
private val Muted = Color(0xFF9BAAC4)
private val Red = Color(0xFFFF8797)
private val Amber = Color(0xFFFFC66D)

private data class TestResult(
    val host: String,
    val dnsOk: Boolean? = null,
    val dnsMs: Long? = null,
    val httpCode: Int? = null,
    val httpsMs: Long? = null,
    val error: String? = null
) {
    val httpsOk get() = httpCode != null
}

private val targets = listOf("www.instagram.com", "www.tiktok.com", "github.com")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OpenRouteApp() }
    }
}

@Composable
private fun OpenRouteApp() {
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(targets.map { TestResult(it) }) }
    var lastTest by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf("Tanılama") }
    var history by remember { mutableStateOf(listOf<Long>()) }
    val passed = results.count { it.dnsOk == true && it.httpsOk }
    val completed = results.count { it.dnsOk != null }

    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, secondary = Color(0xFF9CB9FF), background = Ink, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("OpenRoute", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Mint)
                        Text("AĞ SAĞLIĞI  /  ANDROID", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                    Box(Modifier.background(if (running) Amber.copy(alpha = .15f) else Mint.copy(alpha = .13f), RoundedCornerShape(30.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(if (running) "TEST EDİLİYOR" else "● HAZIR", color = if (running) Amber else Mint, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Tanılama", "VPN").forEach { item ->
                        FilterChip(selected = screen == item, onClick = { screen = item }, label = { Text(item) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (screen == "VPN") {
                    VpnInfoCard()
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Bağlantı özeti", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text(if (completed == 0) "Henüz test yapılmadı" else "$passed / ${results.size} hedefte DNS ve HTTPS yanıtı alındı", color = Muted)
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        MetricTile("DNS", "${results.count { it.dnsOk == true }}/${results.size}", Modifier.weight(1f))
                                        MetricTile("HTTPS", "${results.count { it.httpsOk }}/${results.size}", Modifier.weight(1f))
                                        MetricTile("Hedef", "${results.size}", Modifier.weight(1f))
                                    }
                                    if (history.isNotEmpty()) {
                                        Text("Son testlerin yanıt süresi eğilimi", color = Muted, style = MaterialTheme.typography.labelMedium)
                                        MiniChart(history)
                                    }
                                    Button(onClick = {
                                        if (!running) {
                                            running = true
                                            scope.launch {
                                                val updated = withContext(Dispatchers.IO) { targets.map { runTest(it) } }
                                                results = updated
                                                val average = updated.mapNotNull { it.httpsMs }.average().toLong().coerceAtLeast(0)
                                                history = (history + average).takeLast(12)
                                                lastTest = SimpleDateFormat("dd MMM yyyy • HH:mm:ss", Locale("tr", "TR")).format(Date())
                                                running = false
                                            }
                                        }
                                    }, modifier = Modifier.fillMaxWidth(), enabled = !running, shape = RoundedCornerShape(14.dp)) {
                                        Text(if (running) "Test ediliyor…" else if (lastTest == null) "Testi başlat" else "↻  Yeniden test et", fontWeight = FontWeight.Bold)
                                    }
                                    if (running) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint)
                                    Text("Son test: ${lastTest ?: "—"}", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        item { Text("HEDEF DURUMU", color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                        items(results, key = { it.host }) { ResultCard(it) }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .7f)), shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Kodları nasıl okumalı?", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("200: Sunucu yanıt verdi. 404: Sunucuya ulaşıldı ancak bu adres/kaynak bulunamadı; tek başına engel kanıtı değildir.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    Text("DNS hatası: Alan adı IP adresine çevrilemedi. HTTPS hatası: Zaman aşımı, ağ/DNS sorunu, TLS veya sunucu kaynaklı olabilir.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        item { Text("Gizlilik: Testler yalnızca bu ekranda listelenen alan adlarına DNS/HTTPS isteği gönderir. Sonuçlar bu oturumda tutulur.", color = Muted, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Ink, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
        Text(value, color = Mint, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MiniChart(values: List<Long>) {
    Canvas(Modifier.fillMaxWidth().height(58.dp)) {
        if (values.size < 2) return@Canvas
        val max = (values.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
        val min = (values.minOrNull() ?: 0L).toFloat()
        val range = (max - min).coerceAtLeast(1f)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size - 1).toFloat()
            val y = size.height - ((v - min) / range) * (size.height * .75f) - size.height * .1f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, Mint, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
    }
}

@Composable
private fun ResultCard(result: TestResult) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(result.host, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(when { result.dnsOk == null -> "BEKLİYOR"; result.dnsOk && result.httpsOk -> "YANIT VAR"; else -> "KONTROL ET" }, color = when { result.dnsOk == null -> Muted; result.dnsOk && result.httpsOk -> Mint; else -> Amber }, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill("DNS", when (result.dnsOk) { true -> "Başarılı"; false -> "Hata"; null -> "—" }, result.dnsOk == true)
                StatusPill("HTTPS", result.httpCode?.let { "HTTP $it" } ?: if (result.httpsOk) "Yanıt var" else if (result.error != null) "Hata" else "—", result.httpsOk)
            }
            if (result.dnsMs != null || result.httpsMs != null) Text("DNS ${result.dnsMs ?: "—"} ms   •   HTTPS ${result.httpsMs ?: "—"} ms", color = Muted, style = MaterialTheme.typography.bodySmall)
            val explanation = when {
                result.dnsOk == null -> "Test başlatılmadı."
                result.dnsOk == false -> "DNS başarısız: internet bağlantısı, DNS sunucusu veya alan adı yanıtı kontrol edilmeli."
                result.httpCode == 404 -> "Sunucuya ulaşıldı; bu URL için kaynak bulunamadı. Bu, tek başına ağ engeli değildir."
                result.httpCode != null -> "HTTP ${result.httpCode}: Sunucu HTTP yanıtı verdi. Bu, uygulamanın tüm içeriğinin erişilebilir olduğunu garanti etmez."
                else -> result.error ?: "HTTPS bağlantısı kurulamadı. Zaman aşımı, TLS, DNS veya sunucu sorunu olabilir."
            }
            Text(explanation, color = if (result.dnsOk == false || result.error != null) Amber else Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun StatusPill(label: String, value: String, ok: Boolean) {
    Row(Modifier.background((if (ok) Mint else Amber).copy(alpha = .12f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
        Text(value, color = if (ok) Mint else Amber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun VpnInfoCard() {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("OpenRoute VPN", color = Mint, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Güvenli yönlendirme için temel hazır; şu an bu sürüm VPN tüneli kurmaz.", color = Color.White, style = MaterialTheme.typography.bodyLarge)
            Text("Gerçek VPN bağlantısı için güvenilir bir VPN sunucusu veya uyumlu tünel uç noktası ve protokol (ör. WireGuard) gerekir. Sunucu olmadan yalnızca Android VPN iznini istemek interneti yönlendirmez.", color = Muted)
            Text("Bu sürüm bilerek sahte bir 'Bağlandı' durumu göstermiyor. Sonraki adım, sunucu yapılandırması ve anahtarların güvenli yönetimini eklemek.", color = Muted)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("●", color = Amber)
                Text("VPN yapılandırılmadı", color = Amber, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun runTest(host: String): TestResult {
    var dnsOk = false
    var dnsMs: Long? = null
    val dnsStart = System.nanoTime()
    try {
        dnsOk = InetAddress.getAllByName(host).isNotEmpty()
        dnsMs = (System.nanoTime() - dnsStart) / 1_000_000
    } catch (_: Exception) { dnsMs = (System.nanoTime() - dnsStart) / 1_000_000 }

    var code: Int? = null
    var httpsMs: Long? = null
    var error: String? = null
    var connection: HttpsURLConnection? = null
    val start = System.nanoTime()
    try {
        connection = (URL("https://$host/").openConnection() as HttpsURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            requestMethod = "GET"
            setRequestProperty("Range", "bytes=0-0")
            instanceFollowRedirects = true
        }
        code = connection.responseCode
        httpsMs = (System.nanoTime() - start) / 1_000_000
    } catch (e: Exception) {
        httpsMs = (System.nanoTime() - start) / 1_000_000
        error = when (e) {
            is java.net.SocketTimeoutException -> "Zaman aşımı: sunucu yanıt vermedi."
            is java.net.UnknownHostException -> "Alan adı çözümlenemedi (DNS)."
            is javax.net.ssl.SSLException -> "TLS/sertifika bağlantı hatası."
            else -> "Bağlantı hatası: ${e.javaClass.simpleName}."
        }
    } finally { connection?.disconnect() }
    return TestResult(host, dnsOk, dnsMs, code, httpsMs, error)
}
